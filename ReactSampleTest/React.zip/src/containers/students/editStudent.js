import React, { Component } from "react";
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  FormGroup,
  Label,
  Input,
} from "reactstrap";

export default class editStudent extends Component {
  render() {  
    return (
      <div>
        <Modal
          isOpen={this.props.editStudentModal}
          toggle={this.props.toggleEditStudentModal}
        >
          <ModalHeader toggle={this.props.toggleEditStudentModal}>
            Update  
          </ModalHeader>
          <ModalBody>
            <FormGroup>
              <Label for="title">title </Label>
              <Input
                id="title"
                name="title"
                value={this.props.editStudentData.title}
                onChange={this.props.onChangeEditStudentHanler}
              />
            </FormGroup>
            <FormGroup>
              <Label for="remarks">remarks </Label>
              <Input
                id="remarks"
                name="remarks"
                value={this.props.editStudentData.remarks}
                onChange={this.props.onChangeEditStudentHanler}
              />
            </FormGroup>
 
          
          </ModalBody>
          <ModalFooter>
            <Button 
              color="primary" 
              onClick={this.props.updateStudent}
            >
              Update
            </Button>
            <Button
              color="secondary"
              onClick={this.props.toggleEditStudentModal}
            >
              Cancel
            </Button>
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}
