import React, { Component } from "react";
import {
    Button,
    Modal,
    ModalHeader,
    ModalBody,
    ModalFooter,
    FormGroup,
    Label,
    Input,
  } from "reactstrap";

export default class addStudents extends Component {
  render() {
    return (
      <div>
        <Button
          className="float-right mb-4"
          color="primary"
          onClick={this.props.toggleNewStudentModal}
        >
          Add  
        </Button>
        <Modal
          isOpen={this.props.newStudentModal}
          toggle={this.props.toggleNewStudentModal}
        >
          <ModalHeader toggle={this.props.toggleNewStudentModal}>
            Add new  
          </ModalHeader>
          <ModalBody>
            <FormGroup>
              <Label for="title">title </Label>
              <Input
                id="title"
                name="title"
                value={this.props.newStudentData.title}    onChange={this.props.onChangeAddStudentHandler}
              />
            </FormGroup>
            <FormGroup>
              <Label for="remarks">remarks </Label>
              <Input
                id="remarks"
                name="remarks"
                value={this.props.newStudentData.remarks}    onChange={this.props.onChangeAddStudentHandler}
              />
            </FormGroup>

           
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={() => this.props.addStudent()}>
              Add
            </Button>{" "}
            <Button color="secondary" onClick={this.props.toggleNewStudentModal}>
              Cancel
            </Button>
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}
